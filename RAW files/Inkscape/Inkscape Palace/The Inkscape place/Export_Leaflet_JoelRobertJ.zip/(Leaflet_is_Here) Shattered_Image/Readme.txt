Name: Joel Robert Justiawan
NIM: 2101629672

Title: Shattered Image

A brochure about introduction of Joel's company, Perkedel Technologies.
It explains its philosophy behind the slogan "Share and Serve for Gratis, Open Source, FULL VERSION!!!", Project the company do, and contacts.

Contains some clue and usable codes. Who knows.

Place your confusion bellow your application on your smartphone.
Brochured! don't throw away! Graces awaits for loyal holder of this!

if the front page is dark. try to put the page on white surface.

Fold: C fold. Middle flap is base. Wrap Confusion/contacts flap, then the title flap.

by JOELwindows7
Perkedel Technologies
CC4.0-BY-SA